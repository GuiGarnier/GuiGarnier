<!-- https://towardsdatascience.com/build-a-stunning-readme-for-your-github-profile-9b80434fe5d7 !-->

# Hello, folks! <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">
<!-- <img src="https://raw.githubusercontent.com/darkguinito/darkguinito/master/avatar2.png" width="100px">-->


## &#x1f4c8; GitHub Stats


<a href="https://github.com/darkguinito/darkguinito">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=darkguinito&layout=compact&title_color=ffffff&text_color=c9cacc&icon_color=2bbc8a&bg_color=1d1f21" />
</a>
<a href="https://github.com/MartinHeinz/MartinHeinz">
  <img align="center" src="https://github-readme-stats.vercel.app/api?username=darkguinito&show_icons=true&title_color=ffffff&text_color=c9cacc&icon_color=2bbc8a&bg_color=1d1f21" />
</a>

<!-- Actual text -->

You can find me on [![Slack][1.2]][1], or on [![Google][2.2]][2], or on [![Linkedin][3.2]][3].

<!-- Icons -->

[1.2]: https://raw.githubusercontent.com/darkguinito/darkguinito/master/slack.png (slack icon without padding)
[2.2]: https://raw.githubusercontent.com/darkguinito/darkguinito/master/google.png (Google icon without padding)
[3.2]: https://raw.githubusercontent.com/darkguinito/darkguinito/master/linkedin.png (Linkedin icon without padding)

<!-- Links to your social media accounts -->

[1]: https://slack.com/darkguinito
[2]: https://www.google.com/in/guillaume-garnier
[3]: https://www.linkedin.com/in/guillaume-garnier-7325b377


